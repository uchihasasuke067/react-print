import type { UseReactToPrintOptions } from "../types/UseReactToPrintOptions";
export declare function removePrintIframe(preserveAfterPrint: UseReactToPrintOptions["preserveAfterPrint"], force?: boolean): void;
