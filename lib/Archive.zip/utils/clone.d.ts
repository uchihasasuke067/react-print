export declare function cloneShadowRoots(sourceNode: Node, targetNode: Node, suppressErrors: boolean): void;
