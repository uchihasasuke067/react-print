export declare function generatePrintWindow(): HTMLIFrameElement;
