export type ContentNode = Element | Text | null | undefined;
