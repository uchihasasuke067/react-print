import type { UseReactToPrintHookContent } from "./UseReactToPrintHookContent";
export type UseReactToPrintFn = (content?: UseReactToPrintHookContent) => void;
