import { ContentNode } from "./ContentNode";
export type UseReactToPrintHookContent = () => ContentNode;
