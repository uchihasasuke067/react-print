export type Font = {
    family: string;
    source: string;
    weight?: string;
    style?: string;
};
