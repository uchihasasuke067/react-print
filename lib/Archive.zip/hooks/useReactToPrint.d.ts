import type { UseReactToPrintOptions } from "../types/UseReactToPrintOptions";
import { UseReactToPrintFn } from "../types/UseReactToPrintFn";
export declare function useReactToPrint(options: UseReactToPrintOptions): UseReactToPrintFn;
